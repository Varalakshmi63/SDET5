package com.fannie.service;

import java.util.List;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.fannie.beans.Message;

public class MessageService {
	
Map<Long, Message> messages = new HashMap<Long, Message>();
	
	public MessageService(){
		System.out.println("Constructor invoked for Message Service... ");

		Message m1 = new Message();
		m1.setMessageId(101);
		m1.setAuthor("Jane");
		m1.setMsg("It's a gorgeous day outside, how is it going for you?");
		//m1.setDt(Calendar.getInstance().getTime());
		m1.setDt("04-JUN-2017");
		
		
		Message m2 = new Message();
		m2.setMessageId(102);
		m2.setAuthor("Joe");
		m2.setMsg("Today will be a rainy day, do you have any outdoor plans?");
		m2.setDt("04-JUN-2017");
		
		
		Message m3 = new Message();
		m3.setMessageId(103);
		m3.setAuthor("Jill");
		m3.setMsg("It is very hot out there, will you relax at home?");
		m3.setDt("04-JUN-2017");
		
		Message m4 = new Message();
		m4.setMessageId(104);
		m4.setAuthor("Jane");
		m4.setMsg("Ideal day for gardening, please get busy :)");
		m4.setDt("04-JUN-2017");
		
		messages.put(101L, m1);
		messages.put(102L, m2);
		messages.put(103L, m3);
		messages.put(104L, m4);
	}

	public Message getMessage(long messageId){
		return messages.get(messageId);

	}
	
	public List<Message> getAllMessages(){
		return new ArrayList<Message>(messages.values());
	}
	
	/*public Message getMessageAuthor(){
		return messages.get(author);
	}*/
	
	public Message insertMessage(Message message){
		messages.put( (long)message.getMessageId(), message);
		return message;
	}
	
	public Message updateeMessage(Message message){		
		messages.put( (long)message.getMessageId(), message);
		return message;
	}

	public String deleteMessage (long messageId){
		if(this.getMessage(messageId)!=null){
			messages.remove(messageId);
			return "Message Deleted "+ messageId;
		}else{
			return "Sorry Message Not Found: " + messageId;
		}
	}

}
