package com.fannie.day3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import org.omg.Messaging.SyncScopeHelper;

import com.fannie.day2.Person;

public class SerializeExample {
	

	public static void storeObject(Person per){

		
		ObjectOutputStream oos = null;
		
		try {
			 oos = new ObjectOutputStream(
					new FileOutputStream("person.ser"));
			
			oos.writeObject(per);
			oos.writeObject(new string);
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				oos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Data Saved Successfully...... ");
		
	}
	

	
	public static void readObject() throws FileNotFoundException, IOException, ClassNotFoundException{
		ObjectInputStream ois = (
				new ObjectInputStream(new FileInputStream("pserson.ser")));
		
		Person object = null;
		if(object instanceof Person){
			System.out.println(object);
		}else
		if(object instanceof Person){
			Person p = (Person) object;
			System.out.println(p);
		}
		
		//Person person = (Person) ois.readObject();
		
		//System.out.println(person);
	}
	
	public static void main(String[] args){
		//Person p = new Person(101, "Becky", 221221);
		//storeObject(p);
		
		try {
			readObject(per); //CHECK NAVEEN SLIDE AND CORRECT THIS
			
		}catch(ClassNotFoundException | IOException e){
			e.printStackTrace();
		}
		

}
	
}
