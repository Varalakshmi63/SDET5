package com.fannie.day3;

import java.io.File;

public class GetFiles {
	public static void main(String[] args) {
		File f = new File("fannie");
		
		//System.out.println(f.isFile());
		
		//File files [] = f.listFiles();
		//for(File temp: files){
			
			
			File testDirectory = new File("C:/workspace/JavaWorks/fannie");

			File[] files = testDirectory.listFiles();

			for (File file : files) {

			  if ( (file.isDirectory() == false) && (file.getAbsolutePath().endsWith(".txt") )); 
			  
			//System.out.println((((String) temp.getAbsoluteFile())).endsWith(".txt"));
			
			
			//System.out.println(temp.getName());
		}
	}

}
