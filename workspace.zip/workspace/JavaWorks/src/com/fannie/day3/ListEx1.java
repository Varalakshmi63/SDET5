package com.fannie.day3;

import java.util.List;
import java.util.ArrayList;

public class ListEx1 {
	public static void main(String[] args){
		
		List list = new ArrayList();
		int x = 333;
		
		list.add(10);
		list.add(x);
		list.add("hello");
		list.add(222.44);
		list.add(new Object(){});
		
		for(Object temp: list){
			System.out.println(temp);
		}
	}

}
