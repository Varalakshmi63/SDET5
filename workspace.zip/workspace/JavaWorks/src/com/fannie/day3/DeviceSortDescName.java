package com.fannie.day3;

public class DeviceSortDescName {
	
	public class DeviceSortDescName implements Comparator<Device>{
		
		@Override
		public int compare(Device o1, Device o2){
			return o2.getName().compareTo(o1.getdName());
		}
		
		//method in the class DeviceSortDescName
		public static Comparator<Device> sortDescOnName(){
			return new Comparator<Device> {
				
				@Override
				public int compare(Device o1, Device o2){
					// TODO Auto-generated method stub
					return o2.getdName().compareTo(o1.getdName());
				}
			}
		}
	}

}
