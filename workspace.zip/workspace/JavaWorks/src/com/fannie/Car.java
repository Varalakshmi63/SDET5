package com.fannie;

public class Car extends Vehicle {
	
	public Car() {
		System.out.println("Car constructed..... ");
	}
	
	public void steering(){
		System.out.println("Car has a steering");
	}
	
	public void fuelCapacity(int capacity){
		System.out.println("Car Capacity " + capacity);
	}

}
