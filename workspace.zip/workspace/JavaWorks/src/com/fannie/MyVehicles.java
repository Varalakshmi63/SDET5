package com.fannie;

public abstract class MyVehicles {
	public abstract void move ();
	public abstract void breaks ();

}

class Jaguar extends MyVehicles{

	@Override
	public void move() {
		System.out.println("This 'Jaguar' moves forward when you accelerate");
		
	}

	@Override
	public void breaks() {
		System.out.println("This 'Jaguar' stops when you break");
		
	}
	
}

class Harley extends MyVehicles{

	@Override
	public void move() {
		System.out.println("This 'Harley' moves forward when you accelerate");
		
	}

	@Override
	public void breaks() {
		System.out.println("This 'Harley' stops when you break");
		
	}
	
}

class Huffy extends MyVehicles{

	@Override
	public void move() {
		System.out.println("This 'Huffy' moves forward when you accelerate");
		
	}

	@Override
	public void breaks() {
		System.out.println("This 'Huffy' stops when you break");
		
	}
	
}

class Freightliner extends MyVehicles{

	@Override
	public void move() {
		System.out.println("This 'Freightliner' moves forward when you accelerate");
		
	}

	@Override
	public void breaks() {
		System.out.println("This 'Freightliner stops when you break");
		
	}
	
}