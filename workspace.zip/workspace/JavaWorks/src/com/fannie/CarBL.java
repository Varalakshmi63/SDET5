package com.fannie;

public class CarBL {
	public void ShowCar (Car [] cars){
		for(Car temp : cars){
			System.out.println("----------------");
			temp.move();
			temp.brake();
			temp.fuelCapacity(55);
			temp.steering();
			
			if(temp instanceof Mercedes){
				((Mercedes) temp).abs();
			}else if (temp instanceof BMW){
				((BMW) temp).gps();
			}
		}
			
	}


}
