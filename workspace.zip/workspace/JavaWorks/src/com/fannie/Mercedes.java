package com.fannie;

public class Mercedes extends Car{
	
	public Mercedes() {
		System.out.println("Mercedes constructed... ");
	}
	public void abs(){
		System.out.println("Mercedes has ABS....");
	}
	
	@Override
	public void move(){
		System.out.println("Mercedes is Moving... ");
	}
	@Override
	public void brake() {
		System.out.println("Mercedes applied Break... ");
	}
	
	

}
