package com.fannie;

public class BMW extends Car{
	public BMW() {
		System.out.println("BMW constructed.... ");
	}
	public void gps(){
		System.out.println("BMW has GPS....");
	}
	

}
