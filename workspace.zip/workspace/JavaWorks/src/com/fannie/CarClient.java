package com.fannie;

public class CarClient {
	public static void main(String[] args){
		/*Mercedes m = new Mercedes();
		m.abs();
		m.move();
		m.brake();*/
		
		//BMW b = new BMW();
		
		Car cars [] = new Car[5];
		cars[0] = new Mercedes();
		cars[1] = new BMW();
		cars[2] = new Mercedes();
		cars[3] = new BMW();
		cars[4] = new Mercedes();
		
		CarBL cbl = new CarBL();
		cbl.ShowCar(cars);
		
		/*for(Car temp : cars){
			System.out.println("----------------");
			temp.move();
			temp.brake();
			temp.fuelCapacity(55);
			temp.steering();
			
			if(temp instanceof Mercedes){
				((Mercedes) temp).abs();
			}else if (temp instanceof BMW){
				((BMW) temp).gps();
			}
		}
			
	}*/
	}	
	
}
