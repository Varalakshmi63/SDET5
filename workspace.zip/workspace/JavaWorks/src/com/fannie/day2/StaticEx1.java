package com.fannie.day2;

public class StaticEx1 {
	
	static int snum1 = 100;
	int x;
	
	// when we say as static, to access this method
	// creating an object is not required, and this method
	// is available by reference only no by
	// Instantiation, doing so will not even create an object
	// all statics are singleton (one instance only)
	public static int add(int num1, int num2){
		System.out.println("SNum1 " + snum1);
		return num1 + num2;
	}
	
	static{
		System.out.println("Hey I'm static block ");
		
	}
	
	static{
		System.out.println("Hey I'm second static block.... ");
	}
	
	public static void main(String[] args){
		
		int res = add(10, 20);
		System.out.println("Result " + res);
		
	}
	
	public static int main(String args){
		return 0;
	}
	
	public static void hello(String args[]){
		
	}
	
	

}
