package com.fannie.day2;

import java.util.Arrays;
import java.util.Comparator;

public class PersobSorterTemplate {
	
	public static void sortOnIdAsc(Person[] pers){
		
		Arrays.sort(pers, new Comparator<Person()> {
			
			
		}
	})

}
