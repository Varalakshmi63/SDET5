package com.fannie;

public class MyVehiclesClient {
	public static void main(String[] args){ 
		MyVehicles v[] = new MyVehicles[4];
		
		v[0] = new Jaguar();
		v[1] = new Harley();
		v[2] = new Huffy();
		v[3] = new Freightliner();
		
		for(MyVehicles temp : v){
			System.out.println("---------------------------------------------------");
			temp.move();
			temp.breaks();
		}
		  
		  
		
	}

}
