package com.fannie.day4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class MapEx1 {
	public static void main(String[] args){
		Map<String, Integer> accounts = new HashMap<String, Integer>();
		
		accounts.put("Abdul", 10000);
		accounts.put("Suresh", 20000);
		accounts.put("Peter", 5000);
		
		/*System.out.println("Abdul's Balance is -> " + accounts.get("abdul"));
		System.out.println("Suresh's Balance is -> " + accounts.get("suresh"));
		System.out.println("Peter's Balance is -> " + accounts.get("peter"));*/
		
		/*accounts.put("abdul", 12345);
		System.out.println("Abdul's Balance is -> " + accounts.get("abdul"));*/
		
		
		Iterator itr = accounts.entrySet().iterator();
		
		//hasNext will check for element
		while(itr.hasNext()){
			// get the value from the set and keep it in map
			// as a temp object
			
			/* interface Map{
			 * 	interface Entry{
			 * 
			 * 	}
			 */
			
			Map.Entry<String, Integer> temp = (Entry<String, Integer>) itr.next();
			
			System.out.println("Key -> " + temp.getKey()
				+", Value  -> " + temp.getValue());
		}
	
	}

}
