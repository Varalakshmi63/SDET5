package com.fannie.test;

import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.RestAssured.when;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static com.jayway.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import static org.hamcrest.Matchers.containsString;
import static org.junit.Assert.*;

import org.hamcrest.Matcher;
import org.junit.BeforeClass;
import org.junit.Test;

import com.fannie.beans.Message;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;

public class MessageTest {

	// the  is init section where we specify URL

		@BeforeClass
		public static void init() {
			String url = "http://localhost:9090/ProjectRest/resources";
			RestAssured.baseURI = url;
		}


		// Save a new Message
		// ------------------
		@Test
		public void postMessageTest() {
			Message message = new Message();
			message.setMessageId(105);			
			message.setAuthor("John");
			message.setMsg("Winter weather warning, you can stay indoors!");
			message.setDt("04-JUN-2017");
			
			given().contentType(ContentType.JSON)
			.body(message)
			.when()
			.post("/message")
			.then()
			.statusCode(200)
			.body("messageId", is(message.getMessageId()))
			.body("author", is(message.getAuthor()))
			.body("msg", is(message.getMsg()))
			.body("dt", is(message.getDt()));
			
		}

		
		// Save a new Message and get path
		// -------------------------------
		@Test(timeout=3000)
		public void postMessageFullTest(){
			
			Message message = new Message();
			message.setMessageId(106);
			message.setAuthor("Jack");
			message.setMsg("Gloomy day today, do you want to delete this message");
			message.setDt("04-JUN-2017");
			
			int messageId =
			given().contentType(ContentType.JSON)
			.body(message)
			.when()
			.post("/message")
			.then()
			.statusCode(200)
			.body("messageId", is(message.getMessageId()))
			.body("author", is(message.getAuthor()))
			.body("msg", is(message.getMsg()))
			.body("dt", is(message.getDt()))
			.extract()
			.path("messageId");
			
			// get path
			
			given().pathParam("messageId", messageId)
			.when().get("/message/{messageId}").then()
			.statusCode(200)
			.body("messageId", is(message.getMessageId()))
			.body("author", is(message.getAuthor()))
			.body("msg", is(message.getMsg()))
			.body("dt", is(message.getDt()));

		}

		
		// Update a Message with ID
		// ------------------------
		@Test
		public void updateMessageTest() {
			
			Message message = new Message();
			
			message.setMessageId(105);
			message.setAuthor("Jimmy Carter");
			message.setMsg("Winter weather warning, you can stay indoors!");
			message.setDt("04-JUN-2017");
			
			given()
			.body(message)
			.contentType(ContentType.JSON)
			.put("/messages/105");
			
		}
		
		
		// Delete a Message with ID
		// ------------------------
		@Test
		public void deleteMessageWithIdTest(){
			
			given()
			.pathParam("messageId", 106)
			.when().delete("/message/{messageId}")
			.then().statusCode(200);
			
			given()
			.pathParam("messageId", 108)
			.when().delete("/message/{messageId}")
			.then().statusCode(200);
			
		}
		
		
		// Delete a Message with Author
		// ----------------------------
		public void deleteMessageWithAuthorTest(){
			
			String at3 = "Jill";
			
			given()
			.param("author", at3)
			.when()
			.get("/message/103");
			
			given()
			.pathParam("messageId", 103)
			.when().delete("/message/{messageId}")
			.then().statusCode(200);
		}
		
		
		// Get All Messages
		// ----------------
		@Test
		public void getAllMessagesTest() {
			
			when()
			.get("/message")
			.then()
			.statusCode(200);

		}
		
		
		// Get Message based on ID
		// -----------------------
		@Test
		public void getMessageWithIdTest() {
			int id = 103;

			given().
				pathParam("messageId", id).
				when().
				get("/message/{messageId}").
				then().
					statusCode(200)
					.body("messageId", is(id))
					.body("author", is("Jill"))
					.body("msg", is("It is very hot out there, will you relax at home?"))
					.body("dt", is("04-JUN-2017"));

		}
		
	
		// Get a Message based on Author (when there is ONLY ONE MESSAGE for an Author)
		// -----------------------------------------------------------------------------
		@Test
		public void getMessageWithAuthorTest() {
	
			String at = "Joe";

			given().
			param("author", at)
			.when()
			.get("/message/102")
			.then().
				statusCode(200)
				.body("messageId", is(102))
				.body("author", is(at))
				.body("msg", is("Today will be a rainy day, do you have any outdoor plans?"))
				.body("dt", is("04-JUN-2017"));
	}
	
		// Get Messages based on Author (when there are MORE THAN ONE MESSAGE for an Author
		// --------------------------------------------------------------------------------
		@Test
		public void getManyMessagesWithAuthorTest(){
			
			String at2 = "Jane";
			
			given().
			param("author", at2)
			.when()
			.get("/message/101")
			.then().
				statusCode(200)
				.body("messageId", is(101))
				.body("author", is(at2))
				.body("msg", is("It's a gorgeous day outside, how is it going for you?"))
				.body("dt", is("04-JUN-2017"));
			
			given().
			param("author", at2)
			.when()
			.get("/message/104")
			.then().
				statusCode(200)
				.body("messageId", is(104))
				.body("author", is(at2))
				.body("msg", is("Ideal day for gardening, please get busy :)"))
				.body("dt", is("04-JUN-2017"));
		}

}
