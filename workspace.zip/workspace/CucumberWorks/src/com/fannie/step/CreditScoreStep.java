package com.fannie.step;

import cucumber.api.java.en.And;
import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreditScoreStep {
// step definition to go here
	
	@Given("Employee has a credit score")
	public void employee_has_a_credit_score(){
		System.out.println("Employee has a credit score>>>>>>>");
	}
	
	@And("according to bank standard")
	public void according_to_bank_standard(){
		System.out.println("according to bank standard>>>>>>>");
		
	}
		
	@When("Customer has full time work")
	public void customer_has_full_time_work(){
		System.out.println("Customer has full time work>>>>>>>");
	}
	
	@And("in a government office")
	public void in_a_government_office(){
		System.out.println("in a government office>>>>>>>>>>");	
		
	}
	
	@Then("Sanction loan")
	public void sanction_loan(){
		System.out.println("Saction loan>>>>>>>>>>>>");
	}
	
	@But("should repay within 5 years")
	public void should_repay_within_5_years(){
		System.out.println("should repay within 5 years>>>>>>>>>>");
	}
}
