package com.fannie.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GetConnection {
	// all DB connection variables shall be kept here
	static Connection conn = null;
	public PreparedStatement ps, ps1;
	public ResultSet rs;
	
	public static Connection getMySQLConnection(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sdet5", "root", "hexaware");
			
			return conn;
		} catch (ClassNotFoundException e) {
					e.printStackTrace();
		
		} catch (SQLException e) {
				e.printStackTrace();
		}
		
		return null;
		
	}

}
