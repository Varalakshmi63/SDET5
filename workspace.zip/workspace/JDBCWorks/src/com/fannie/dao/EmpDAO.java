package com.fannie.dao;

import java.sql.SQLException;
import java.util.List;

import com.fannie.beans.Employee;
import com.fannie.connection.GetConnection;
import com.fannie.contract.IEmpDAO;

public class EmpDAO implements IEmpDAO {

	public boolean insertEmp(Employee emp) {
		// TODO Auto-generated method stub
		//return false;
		
		String sql = "insert into emp values(?,?,?,?)";
		GetConnection gc =new GetConnection();
		
		try {
			gc.ps = GetConnection.getMySQLConnection().prepareStatement(sql);
			gc.ps.setInt(1, emp.getEmpId());
			gc.ps.setString(2, emp.getEmpName());
			gc.ps.setDouble(3, emp.getEmpSal());
			gc.ps.setString(4, emp.getEmail());
			
			return gc.ps.executeUpdate() >0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
			
		
	}

	public boolean updateEmp(int empId, double salary) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean delete(int empId) {
		String sql ="delete from emp where empid =?";
		GetConnection gc  = new  GetConnection();
		try {
			gc.ps = GetConnection.getMySQLConnection().prepareStatement(sql);
			gc.ps.setInt(1, empId);
			return gc.ps.executeUpdate()>0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	
	}

	public Employee getEmp(int empId) {
		String sql = "select empid, empname, empsal, email from emp where empid=? ";
		GetConnection gc = new GetConnection();
		gc.ps = GetConnection.getMySQLConnection().prepareStatement(sql);
		gc.ps.setInt(1, empId);
		
		gc.rs = gc.ps.executeQuery();
		
		if(gc.rs.next()){
			Employee temp = new Employee();
			
			temp.setEmpId(empId);
			// the fields can be referred either by column no or by name
			temp.setEmpName(gc.rs.getString(2));
			temp.setEmpSal(gc.rs.getDouble("empsal"));
			temp.setEmail(gc.rs.getString(4));
			
			return temp;
		}
		return null;
	}

	public List<Employee> getAllEmps() {
		// TODO Auto-generated method stub
		return null;
	}

}
