package com.fannie.dao;

import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

import com.fannie.beans.Customer;
import com.fannie.connection.GetConnection;
import com.fannie.contract.ICustDAO;


public class CustDAO implements ICustDAO {
	
	@Test
	public boolean insertCust(Customer cust) {
		// TODO Auto-generated method stub
		//return false;
		
		String sql = "insert into cust values(?,?,?,?)";
		GetConnection gc =new GetConnection();
		
		try {
			gc.ps = GetConnection.getMySQLConnection().prepareStatement(sql);
			gc.ps.setInt(1, cust.getId());
			gc.ps.setString(2, cust.getCustName());
			gc.ps.setLong(3, cust.getAccNumber());
			gc.ps.setDouble(4, cust.getAccBal());
			gc.ps.setDouble(5, cust.getAvgBal());
			//gc.ps.setInt(6, cust.getPct());
			
			return gc.ps.executeUpdate() >0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
			
		
	}

	@Test
	public boolean updateCust() {			
		return false;
	}

	@Test
	public Customer getId(int accId) throws SQLException {
		String sql = "select accId, accName, accNumber, accBal, avgBal from cust where accId=? ";
		GetConnection gc = new GetConnection();
		gc.ps = GetConnection.getMySQLConnection().prepareStatement(sql);
		gc.ps.setInt(1, accId);
		
		gc.rs = gc.ps.executeQuery();
		
		if(gc.rs.next()){
			Customer temp = new Customer();
			
			temp.setAccId(accId);
			// the fields can be referred either by column no or by name
			temp.setAccName(gc.rs.getString(2));
			temp.setAccNumber(gc.rs.getLong(3));
			temp.setAccBal(gc.rs.getDouble("accBal"));
			temp.setAvgBal(gc.rs.getDouble("avgBal"));
			temp.setPct(gc.rs.getInt(6));
			
			
			return temp;
		}
		return null;
	}

	@Test
	public List<Customer> getAllCusts() {
		return null;
	}

	@Override
	public Customer getCust(int accId) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
