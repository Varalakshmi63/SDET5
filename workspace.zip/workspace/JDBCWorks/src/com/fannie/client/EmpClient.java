package com.fannie.client;

import com.fannie.beans.Employee;
import com.fannie.contract.IEmpDAO;
import com.fannie.dao.EmpDAO;

public class EmpClient {
	public static void main(String[] args) {
		Employee emp = new Employee(101, "Harry", 1212, "harry@gmail.com");
		
		IEmpDAO dao = new EmpDAO();
		
		System.out.println(dao.insertEmp(emp)?"Inserted" : "Sorry Not Inserted");
	}

}
