package com.fannie.client;

import com.fannie.beans.Customer;
import com.fannie.contract.ICustDAO;
import com.fannie.dao.CustDAO;


public class CustClient {
	
	public static void main(String[] args) {
		Customer cust = new Customer(101, "Shannon", 1111, 13000, 1200);
		
		ICustDAO dao = new CustDAO();
		
		System.out.println(dao.insertCust(cust)?"Inserted" : "Sorry Not Inserted");
	}

}
