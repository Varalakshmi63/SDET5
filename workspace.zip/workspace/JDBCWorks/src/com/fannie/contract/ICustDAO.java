package com.fannie.contract;

import java.util.List;

import com.fannie.beans.Customer;

public interface ICustDAO {
	
	// CRUD -> Create, Read, Update, Delete
	
		// insert	
		public boolean insertCust(Customer cust);
		
		// update
		public boolean updateCust();
					
		// get 1 customer
		public Customer getCust(int accId);
		
		// get all
		public List<Customer> getAllCusts();

}
