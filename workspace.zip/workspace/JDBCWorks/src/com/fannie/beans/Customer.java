package com.fannie.beans;

public class Customer {
	
	private int accId;
	private String accName;
	private long accNumber;
	private double accBal;
	private double avgBal;
	private int pct;
	public int getAccId() {
		return accId;
	}
	public int getId() {
		return accId;
	}
	public void setId(int id) {
		accId = id;
	}
	public String getCustName() {
		return accName;
	}
	public void setCustName(String custName) {
		this.accName = custName;
	}
	public long getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}
	public double getAccBal() {
		return accBal;
	}
	public void setAccBal(double accBal) {
		this.accBal = accBal;
	}
	public double getAvgBal() {
		return avgBal;
	}
	public void setAvgBal(double avgBal) {
		this.avgBal = avgBal;
	}		
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public int getPct() {
		return pct;
	}
	public void setPct(int pct) {
		this.pct = pct;
	}
	@Override
	public String toString() {
		return "Customer [accId=" + accId + ", accName=" + accName + ", accNumber=" + accNumber + ", accBal=" + accBal + ", avgBal=" + avgBal + "]" ;
	}
	
	public Customer(){}
	
	public Customer(int accId, String accName, long accNumber, double accBal, double avgBal) {
		super();
		this.accId = accId;
		this.accName = accName;
		this.accNumber = accNumber;
		this.accBal = accBal;
		this.avgBal = avgBal;
		//this.pct = pct;
	}

}
