package com.fannie.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FlighPagePOM {
	private static WebElement element;
	
	public static void clickFlightTab(WebDriver driver){
		driver.findElement(By.id("tab-flight-tab-hp")).click();;
		
	}

	public static void sendflyFromTextBox(String flyFrom, WebDriver driver){
		element = driver.findElement(By.id("flight-origin-hp-flight"));
		element.clear();
		element.sendKeys(flyFrom);
	}
	
	public static void sendflyToTextBox(String flyTo, WebDriver driver){
		element = driver.findElement(By.id("flight-destination-hp-flight"));
		element.clear();
		element.sendKeys(flyTo);
	}
	

	public static void sendDepartDate(String departDate, WebDriver driver){
		element = driver.findElement(By.id("flight-departing-hp-flight"));
		element.clear();
		element.sendKeys(departDate);
	}
	
	public static void sendReturnDate(String returnDate, WebDriver driver){
		element = driver.findElement(By.id("flight-returning-hp-flight"));
		element.clear();
		element.sendKeys(returnDate);
	}
	
	public static void clickSearchButton(WebDriver driver){
		element = driver.findElement(By.xpath("//*[@id='menu_category_Menu_VIfWm2LT_332']/div/div/div[1]/div/ul/li[1]/a/span"));
		element.clear();
		element.click();
		System.out.println("Search Button Clicked");
	}
	
}


