package com.fannie.utility;

public interface Driver {
	// KEYS
	String CHROME = "webdriver.chrome.driver";
	String FIREFOX = "webdriver.firefox.driver";
	String IE = "webdriver.ie.driver";
	String PHANTOM = "phantomjs.binary.path";
	
	// PATH
	String CHROME_PATH="C:\\Software\\selenium-java-3.4.0\\Driver\\chromedriver_win32\\chromedriver.exe";
	String FIREFOX_PATH="C:\\Software\\selenium-java-3.4.0\\geckodriver-v0.16.1-win64\\geckodriver.exe";
	String PHANTOM_PATH="C:\\Software\\phantomjs-2.1.1-windows\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe";
}
