package com.fannie.basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test01 {
	public static void main(String[] args) {
		// Load the Driver
		
		WebDriver driver; 
		
		//System.setProperty("webdriver.gecko.driver", 
		//	"C:\\Software\\selenium-java-3.4.0\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		
		System.setProperty("webdriver.chrome.driver", 				
				"C:\\Software\\selenium-java-3.4.0\\Driver\\chromedriver_win32\\chromedriver.exe");
		//driver = new FirefoxDriver();
		driver = new ChromeDriver();
		
		// Open the Browser for the Driver
		String baseUrl = "http://google.com";
				driver.get(baseUrl);
		
		// Do the task
		System.out.println("Title ->" + driver.getTitle());
				
				// Alt + Shift + Z
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
		// Close the Browser
		driver.close();
	}

}
