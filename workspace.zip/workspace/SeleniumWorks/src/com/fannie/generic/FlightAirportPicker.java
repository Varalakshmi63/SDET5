package com.fannie.generic;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.fannie.generics.GenericMethods;
import com.fannie.utility.Driver;
import com.fannie.utility.WaitTypes;

public class FlightAirportPicker {

	WebDriver driver ; 
	String baseURL;
	GenericMethods genericMethod;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty(Driver.CHROME, Driver.CHROME_PATH);
		//System.setProperty(Driver.FIREFOX, Driver.FIREFOX_PATH);
	}

	@Before
	public void setUp() throws Exception {
		
		
		
		driver = new ChromeDriver();
		
		//driver = new FirefoxDriver();
		
		
	    //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.manage().window().maximize();
		baseURL = "https://www.expedia.com";
		genericMethod = new GenericMethods(driver);
		driver.get(baseURL);
	}



	@After
	public void tearDown() throws Exception {
		Thread.sleep(3000);
		driver.quit();
	}
	
	@Ignore
	@Test
	public void test() 
		throws Exception{
		
		// for email
		/*genericMethod.getElement("ctl00_MPH_txtUserName", "id")
			.sendKeys("cohort303@sdettraining.com");
		// password 
		genericMethod.getElement("ctl00_MPH_txtPassword", "id")
			.sendKeys("Hexaware03!");
		
		// click submit 
		genericMethod.getElement("btnLogin", "id").click();
		
		
		
		// change the iframe 
		driver.switchTo().frame("ctl00_Split_Frame_ContentFrame");
		
		
		WebElement calendarAck =
				genericMethod.getElement("ctl00_MPH_calendarToday__Label", "id");
			
		
		System.out.println("Coming from Server -> " +calendarAck.getText());
		Assert.assertEquals("Testing for Asserting Calendar", "Calendar", calendarAck.getText());*/
		
		genericMethod.getElement("tab-flight-tab-hp", "id").click();
		genericMethod.getElement("flight-departing-hp-flight", "id").click();
		
		String locator = "//*[@id='flight-departing-wrapper-hp-pflight']/div/div/div[2]/table/tbody/tr/td/button[text()='10']";
		String type = "xpath";
		if(genericMethod.checkSingleEntry(locator, type)){
			
			WebElement departDate = genericMethod.getElement(locator, type);
				
				Thread.sleep(2000);
				departDate.click();
					
		}else
			System.out.println("Too many entries of the locator.... ");
		
		//WebElement departDate =
				//genericMethod.getElement("//*[@id='flight-departing-wrapper-hp-pflight']/div/div/div[2]/table/tbody/tr/td/button[text()='10']", "x-path");
		
				//departDate.click();
	
		
		
	}


	@Test
	public void getFlyingFromListTest() throws Exception{
		String flyFromPartial ="new";
		String flyToPartial ="cal";
		Date DepartDate;
		
		//click flight tab
		genericMethod.getElement("tab-flight-tab-hp", "id").click();
		
		// clear and enter partial text on flyForm
		
		genericMethod.getElement("flight-origin-hp-flight", "id").clear();
		genericMethod.getElement("flight-origin-hp-flight", "id").sendKeys(flyFromPartial);
		
		Thread.sleep(3000);
		
		// results-item
		List <WebElement> elements = genericMethod.getElementsAsList("results-item", "class");
		System.out.println("Number of Entries -> " + elements.size());
		
		List<String> flyFromStringList = new ArrayList<String>();
		
		for(WebElement temp : elements){
			System.out.println(temp.getText());
			flyFromStringList.add(temp.getText());
			
		
		}
		
		System.out.println("------------------");
		
		genericMethod.getElement("flight-destination-hp-flight", "id").clear();
		genericMethod.getElement("flight-destination-hp-flight", "id").sendKeys(flyToPartial);
		
		Thread.sleep(3000);
		
		// results-item
		List <WebElement> elements1 = genericMethod.getElementsAsList("results-item", "class");
		System.out.println("Number of Entries -> " + elements1.size());
		
		List<String> flyToStringList = new ArrayList<String>();
		
		for(WebElement temp : elements1){
			System.out.println(temp.getText());
			
		
		}
		
		for(int i=0; i<flyFromStringList.size(); i++){
			//System.out.println("processing");
			genericMethod.getElement("flight-origin-hp-flight", "id").clear();
			genericMethod.getElement("flight-origin-hp-flight", "id").sendKeys(flyFromStringList.get(i));
			
		
		
	}
		
		for(int i=0; i<flyToStringList.size(); i++){
			//System.out.println("processing");
			genericMethod.getElement("flight-destination-hp-flight", "id").clear();
			genericMethod.getElement("flight-destination-hp-flight", "id").sendKeys(flyToStringList.get(i));		
	}
		
		/*String locator = "//*[@id='flight-departing-wrapper-hp-pflight']/div/div/div[2]/table/tbody/tr/td/button[text()='10']";
		String type = "xpath";
		if(genericMethod.checkSingleEntry(locator, type)){
			
			WebElement departDate = genericMethod.getElement(locator, type);
				
				Thread.sleep(2000);
				departDate.click();
				System.out.println("Departing Date selected");
		}*/
		
		/*WebElement departDate = genericMethod.getElement("//*[@id='flight-departing-wrapper-hp-pflight']/div/div/div[2]/table/tbody/tr/td/button[text()='8']", "xpath");

		Thread.sleep(2000);
		departDate.click();
		
		System.out.println("Departing Date is selected " + departDate);*/
		
		Thread.sleep(3000);
		
		// results-item
		List <WebElement> elements2 = genericMethod.getElementsAsList(".//*[@id='flight-departing-hp-flight']/div/div/div[2]/table/tbody/tr/td/button[not (@disabled)]", "xpath");
		System.out.println("Number of Entries -> " + elements2.size());
		
		List<String> DepartdateList = new ArrayList<String>();
		
		for(WebElement temp : elements2){
			//System.out.println(temp.getText());
			System.out.println(temp.getText());			
		
		}
		
		/*for(int i=0; i<DepartdateList.size(); i++){
			//System.out.println("processing");
			genericMethod.getElement("flight-departing-wrapper-hp-flight", "id").clear();
			genericMethod.getElement("flight-departing-wrapper-hp-flight", "id").sendKeys(DepartdateList.get(i));
			
			System.out.println("Dates selected are " + i);
		
	}*/
		
	}
	@Ignore
	@Test
	public void setDepartDateTest() throws Exception{
		
		String locator = "//*[@id='flight-departing-wrapper-hp-pflight']/div/div/div[2]/table/tbody/tr/td/button[text()='8']";
		String type = "xpath";
		if(genericMethod.checkSingleEntry(locator, type)){
			
			WebElement departDate = genericMethod.getElement(locator, type);
				
				Thread.sleep(2000);
				departDate.click();
				System.out.println("Departing Date selected");
		}
		
		//String locator1 = 

		
		
		
	}
}
	
	
