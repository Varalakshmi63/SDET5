package com.fannie.generic;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.fannie.generics.GenericMethods;
import com.fannie.utility.Driver;
import com.fannie.utility.WaitTypes;

public class DatePickerTest {

	WebDriver driver ; 
	String baseURL;
	GenericMethods genericMethod;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty(Driver.CHROME, Driver.CHROME_PATH);
	}

	@Before
	public void setUp() throws Exception {
		
		
		
		driver = new ChromeDriver();
		
		
	    //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.manage().window().maximize();
		baseURL = "https://www.expedia.com";
		genericMethod = new GenericMethods(driver);
		driver.get(baseURL);
	}



	@After
	public void tearDown() throws Exception {
		Thread.sleep(3000);
		driver.quit();
	}
	
	@Ignore
	@Test
	public void test() 
		throws Exception{
		
		// for email
		/*genericMethod.getElement("ctl00_MPH_txtUserName", "id")
			.sendKeys("cohort303@sdettraining.com");
		// password 
		genericMethod.getElement("ctl00_MPH_txtPassword", "id")
			.sendKeys("Hexaware03!");
		
		// click submit 
		genericMethod.getElement("btnLogin", "id").click();
		
		
		
		// change the iframe 
		driver.switchTo().frame("ctl00_Split_Frame_ContentFrame");
		
		
		WebElement calendarAck =
				genericMethod.getElement("ctl00_MPH_calendarToday__Label", "id");
			
		
		System.out.println("Coming from Server -> " +calendarAck.getText());
		Assert.assertEquals("Testing for Asserting Calendar", "Calendar", calendarAck.getText());*/
		
		genericMethod.getElement("tab-flight-tab-hp", "id").click();
		genericMethod.getElement("flight-departing-hp-flight", "id").click();
		
		String locator = "//*[@id='flight-departing-wrapper-hp-pflight']/div/div/div[2]/table/tbody/tr/td/button[text()='10']";
		String type = "xpath";
		if(genericMethod.checkSingleEntry(locator, type)){
			
			WebElement departDate = genericMethod.getElement(locator, type);
				
				Thread.sleep(2000);
				departDate.click();
					
		}else
			System.out.println("Too many entries of the locator.... ");
		
		//WebElement departDate =
				//genericMethod.getElement("//*[@id='flight-departing-wrapper-hp-pflight']/div/div/div[2]/table/tbody/tr/td/button[text()='10']", "x-path");
		
				//departDate.click();
	
		
		
	}

	
	



	@Test
	public void getFlyingFromListTest() throws Exception{
		String partial ="new";
		
		//click flight tab
		genericMethod.getElement("tab-flight-tab-hp", "id").click();
		
		// clear and enter partial text on flyForm
		
		genericMethod.getElement("flight-origin-hp-flight", "id").clear();
		genericMethod.getElement("flight-origin-hp-flight", "id").sendKeys(partial);
		
		Thread.sleep(3000);
		
		// results-item
		List <WebElement> elements = genericMethod.getElementsAsList("results-item", "class");
		System.out.println("Number of Entries -> " + elements.size());
		
		for(WebElement temp : elements){
			System.out.println(temp.getText());
		}
		
		
	}
		
	}
