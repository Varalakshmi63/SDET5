package com.fannie.pomtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class FlightPagePOMFactory {
	private WebDriver driver;
	
	public FlightPagePOMFactory(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	// tab-flight-tab-hp
	@FindBy(id="tab-flight-tab-hp")
	WebElement flightsTab;
	
	@FindBy(id="flight-origin-hp-flight")
	WebElement flyFrom;
	
	@FindBy(id="flight-destination-hp-flight")
	WebElement flyTo;
	
	@FindBy(id="flight-departing-hp-flight")
	WebElement departDate;
	
	@FindBy(id="flight-returning-hp-flight")
	WebElement returnDate;
	
	@FindBy(id="flight-adults-hp-flight")
	WebElement noOfAdults;
	
	//@FindBy(xpath="//*[@id='menu_category_Menu_VIfWm2LT_332']/div/div/div[1]/div/ul/li[1]/a/span")
	//WebElement searchBtn;
	
	
	
	public void clickFlightsTab(){
		flightsTab.click();
	}
	
	public void sendFlyFrom(String flyFrom){
		this.flyFrom.clear();
		this.flyFrom.sendKeys(flyFrom);
	}
	
	public void sendflyTo(String flyTo){
		this.flyTo.clear();
		this.flyTo.sendKeys(flyTo);
	}
	
	public void sendDepartDate(String departDate){
		this.departDate.clear();
		this.departDate.sendKeys(departDate);
	}
	
	public void sendReturnDate(String returnDate){
		this.returnDate.clear();
		this.returnDate.sendKeys(returnDate);
	}
	
	public void selectNoOfAdults(String noOfAdults){
		Select select = new Select(this.noOfAdults);
		select.selectByValue(noOfAdults);
	}
	
	/*public void clickSearchButton(){
		this.searchBtn.click();
	}*/

	
}
