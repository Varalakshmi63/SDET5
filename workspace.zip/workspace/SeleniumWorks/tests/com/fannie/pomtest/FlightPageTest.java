package com.fannie.pomtest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.fannie.pom.FlighPagePOM;
import com.fannie.utility.DriverFactory;
import com.fannie.utility.DriverNames;
import com.fannie.pomtest.FlightPagePOMFactory;

public class FlightPageTest {
	
	WebDriver driver;
	String baseUrl;
	FlightPagePOMFactory flightFactory;


	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		
		//driver = DriverFactory.getDrivers(DriverNames.CHROME);
		driver = DriverFactory.getDrivers(DriverNames.CHROME);
		baseUrl = "https://www.expedia.com/";
		flightFactory = new FlightPagePOMFactory(driver);
		//flightFactory = new flightFactory(driver);
	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
	}

	@Ignore
	@Test
	public void test() {
		driver.get(baseUrl);
		FlighPagePOM.clickFlightTab(driver);	
		FlighPagePOM.sendflyFromTextBox("Washington, DC (IAD-Washington Dulles Intl.)", driver);
		FlighPagePOM.sendflyToTextBox("San Francisco, California", driver);
		FlighPagePOM.sendDepartDate("06/14/2017", driver);
		FlighPagePOM.sendReturnDate("06/23/2017", driver);
		FlighPagePOM.clickSearchButton(driver);
	
	}
	
	@Test
	public void pomFactoryTest(){
		driver.get(baseUrl);
		
		flightFactory.clickFlightsTab();
		flightFactory.sendFlyFrom("Washington, DC (IAD-Washington Dulles Intl.)");
		flightFactory.sendflyTo("San Francisco, California");
		flightFactory.sendDepartDate("06/14/2017");
		flightFactory.sendReturnDate("06/23/2017");
		flightFactory.selectNoOfAdults("3");	
	
		//flightFactory.clickSearch();
		
	}

}
