package com.fannie.basics;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.fannie.utility.Driver;

public class GoogleTest {
  private WebDriver driver;
  private String baseUrl;
 

  @Before
  public void setUp() throws Exception {
	System.setProperty(Driver.CHROME, Driver.CHROME_PATH);
    driver = new ChromeDriver();
	//System.setProperty(Driver.FIREFOX, Driver.FIREFOX_PATH);
	//driver = new FirefoxDriver();
    baseUrl = "https://www.google.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testUntitled() throws Exception {
    driver.get(baseUrl + "/?gws_rd=ssl");
    driver.findElement(By.id("lst-ib")).clear();
    driver.findElement(By.id("lst-ib")).sendKeys("places to visit near me");
    driver.findElement(By.linkText("Reston - Virginia Is For Lovers")).click();
  }

  @After
  public void tearDown() throws Exception {
	Thread.sleep(4000);
    driver.quit();
    
}
  
}
