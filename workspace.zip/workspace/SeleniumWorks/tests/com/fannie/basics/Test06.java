package com.fannie.basics;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.fannie.utility.Driver;

public class Test06 {

	WebDriver driver;
	//String baseURL;
	String baseURL1;
	//String baseURL2;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		
		System.setProperty(Driver.CHROME, Driver.CHROME_PATH);
		
		
	}

	@Before
	public void setUp() throws Exception {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		//baseURL = "http://html.com/attributes/select-multiple/";
		//driver.get(baseURL);
		baseURL1 = "https://www.expedia.com/";
		//baseURL2 = "http://naveenks.com/selenium/RegForm.html";
		
		driver.get(baseURL1);
		//driver.get(baseURL2);
	}

	@After
	public void tearDown() throws Exception {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.quit();
	}
	

	/*@RunWith(Parameterized.class)
	 public static class FibonacciTest {
	     @Parameters(name= "{index}: fib[{0}]={1}")
	     public static Iterable<Object[]> data() {
	         return Arrays.asList(new Object[][] { { 0, 0 }, { 1, 1 }, { 2, 1 },
	                 { 3, 2 }, { 4, 3 }, { 5, 5 }, { 6, 8 } });
	     }

	     private int fInput;

	     private int fExpected;

	     public FibonacciTest(int input, int expected) {
	         fInput= input;
	         fExpected= expected;
	     }

	     @Test
	     public void test() {
	         assertEquals(fExpected, Fibonacci.compute(fInput));
	     }
	 }*/
	
	
	@Test
	public void test() throws Exception {
		
		driver.findElement(By.id("tab-flight-tab-hp")).click();
		
		
		WebElement roomsElement = driver.findElement(By.id("flight-adults-hp-flight"));
		Select roomsSelect = new Select(roomsElement);
		
		
		List<WebElement> options = roomsSelect.getOptions();
		
		for(int i=0; i<options.size(); i++){
			System.out.println(options.get(i).getText());
		}
		
		roomsSelect.selectByIndex(0);
		Thread.sleep(2000);
		
		//roomsSelect.selectByIndex(2);
		//Thread.sleep(3000);
		
		WebElement adultsElement = driver.findElement(By.id("flight-adults-hp-flight"));
		Select adultsSelect = new Select(adultsElement);
		
		String options2 = adultsElement.getText();
		
		for(int i=0; i<options.size(); i++){
			System.out.println(options.get(i).getText());
			
			adultsSelect.selectByIndex(1);
			
		WebElement childrenElement = driver.findElement(By.id("flight-adults-hp-flight"));
		Select childrenSelect = new Select(childrenElement);
		
		//String options3 = newSelect
		}
		
		
	}
		
}


